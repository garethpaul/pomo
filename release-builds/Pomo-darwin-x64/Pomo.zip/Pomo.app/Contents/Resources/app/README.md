# A Pomodoro Electron App

To get started

`npm install`

To start running the app

`npm start`

<img src="https://raw.githubusercontent.com/garethpaul/pomo/master/res/ScreenShot.png" />
